function level = drawEndScreen (imgName, points)

level = drawStartScreen (imgName);

endfunction

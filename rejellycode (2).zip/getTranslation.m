function T = getTranslation(ChangeInX, ChangeInY)

T = [1, 0, ChangeInX; 0, 1, ChangeInY; 0, 0, 1];

endfunction
